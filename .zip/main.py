import discord
from discord.ext import commands
import os

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Bot is online as {bot.user}")

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    if message.content.lower() == "idkzz=best":
        role_name = "shibas shibas"
        guild = message.guild
        member = message.author

        role = discord.utils.get(guild.roles, name=role_name)
        if role:
            await member.add_roles(role)
            await message.channel.send("You are now one of Shibas dogs.")
        else:
            await message.channel.send(f"Role '{role_name}' not found!")

    await bot.process_commands(message)

The bot uses the token from the environment variable "BOT_TOKEN"
bot.run(os.getenv("MTM2MjUxNzI0MzI3NDk4OTcyOQ.GJaua_.GVVnb2z9KB05mbObgB0FUkY7EHhLJXZHSHd-CU "))